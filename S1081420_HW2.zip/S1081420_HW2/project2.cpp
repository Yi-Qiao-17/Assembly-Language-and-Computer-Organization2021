#include<iostream>
#include<fstream>
#include<string>
#include<vector>
#include<sstream>
#include <math.h>
#include<algorithm>
#include <cstdlib>
#include <iomanip>
using namespace std;

vector<string>PC, type, inst, global/*li���F��*/, label;
vector<int>entry_pos,global_num;
vector<string>pattern;
int entry_num;
static string state_format[4] = {"SN","WN","ST","WT"};
static string Right[4] = { "SN","SN","ST","ST" };
static string Wrong[4] = { "WN","WT","WT","WN" };

typedef struct prediction{
	string state_table[4] = {"SN","SN" ,"SN" ,"SN" };//00 01 10 11
	int bit[2] = {0,0};// "10" bit[1]=1, bit[0]=0;
	};
vector<prediction>state(entry_num);
int Base2To10(string binary) {
	int value = 0;
	reverse(binary.begin(), binary.end());
	for (int i = 0; i < binary.size(); i++) {
		value += pow(2, i) * (binary[i] - '0');
	}
	return value;
}

string Base16To2(string pc) {
	string base16bit[16] = { "0000","0001","0010","0011","0100","0101","0110","0111","1000","1001","1010","1011","1100","1101","1110","1111" };
	string value;
	for (int i = 2; i > -1; i--) {
		char tmp = pc[pc.size() - 1 - i];
		switch (tmp) {
		case 'A':
			value += base16bit[10];
			break;
		case 'B':
			value += base16bit[11];
			break;
		case 'C':
			value += base16bit[12];
			break;
		case 'D':
			value += base16bit[13];
			break;
		case 'E':
			value += base16bit[14];
			break;
		case 'F':
			value += base16bit[15];
			break;
		default:
			int num = tmp - '0';
			value += base16bit[num];
			break;
		}
	}
	return value;
}

void CALC_entry(int entry_num) {

	for (int i = 0; i < PC.size(); i++) {
		if (PC[i] != "") {
			string tmp;
			int value = 0;
			tmp = Base16To2(PC[i]);
			tmp = tmp.substr(0, 10);
			value = Base2To10(tmp);
			value = value % entry_num;
			entry_pos.push_back(value);
		}
		else entry_pos.push_back(-1);
	}
}

void CALC_li() {
	for (int i = 0; i < type.size(); i++) {
		if (type[i] == "li") {
			global.push_back(inst[i].substr(0, inst[i].find_first_of(',')));
			string tmp = inst[i].substr(inst[i].find_last_of(',') + 1, inst[i].size() - inst[i].find_last_of(',') - 1) ;
			reverse(tmp.begin(), tmp.end());
			int value = 0;
			for (int j = 0; j < tmp.size(); j++) {
				value += pow(10, j) * (tmp[j] - '0');
			}
			global_num.push_back(value);
		}
	}//��Jli��l��
}//�B�zli

void CALC_branch() {
	vector<int> loop_start_end;
	vector<vector<int>>loop;
	for (int i = 0; i < inst.size(); i++) {
		int begin_branch = i,last_branch;
		string r0 = inst[begin_branch].substr(0, inst[begin_branch].find_first_of(','));//�P�_�O���OR0
		if (type[i] == "beq" ) {//��X�j�骺�}�l�M������branch
			if (r0 == "R0")continue;
			if (label[i - 1] != "") {
				for (int j = i + 1; j < inst.size(); j++) {
					string c = inst[j].substr(inst[j].find_last_of(',') + 1, inst[j].size() - inst[j].find_last_of(',') - 1);//label
					if (c == label[i - 1]) {
						last_branch = j;
					}
				}
			}
			string start_register = inst[begin_branch].substr(0, inst[begin_branch].find_first_of(','));
			string end_register = inst[begin_branch].substr(inst[begin_branch].find_first_of(',') + 1, inst[begin_branch].find_last_of(',') - inst[begin_branch].find_first_of(',') - 1);
			int start_num,end_num;
			//��NNN...NNT
			for (int j = 0; j < global.size(); j++) {
				if (global[j] == start_register) {
					start_num = global_num[j];
				}
				if (global[j] == end_register) {
					end_num = global_num[j];
				}
			}//��X�@�}�lRn����
			int times = 0;//N������
			string pattern_start,pattern_end;
			while (start_num != end_num) {
				times++;
				start_num++;
				pattern_start += 'N';
				pattern_end += 'T';
			}
			pattern_start+= 'T';
			pattern[begin_branch]=pattern_start;
			pattern[last_branch] = pattern_end;
			loop_start_end.push_back( begin_branch);
			loop_start_end.push_back(last_branch);
			loop.push_back(loop_start_end);
			loop_start_end.clear();
		}
		if (type[i] == "bne") {
			string r1 = inst[begin_branch].substr(0, inst[begin_branch].find_first_of(','));
			string r2 = inst[begin_branch].substr(inst[begin_branch].find_first_of(',') + 1, inst[begin_branch].find_last_of(',') - inst[begin_branch].find_first_of(',') - 1);
			int start_num, end_num;
			int loop_times;
			int loop_s=0, loop_e=inst.size();//�ΨӧP�_���Ӱj��]�tbne�ӥB����p
			for (int j = 0; j < loop.size(); j++) {
				if (i > loop[j][0] && i < loop[j][1]) {
					if (loop[j][0] > loop_s)loop_s = loop[j][0];
					if(loop[j][1]<loop_e)loop_e = loop[j][1];
				}
			}
			loop_times = pattern[loop_e].size();
			string loop_pattern;
			bool addi = false;
			for (int j = 0; j < i; j++) {
				if (inst[j].substr(0, inst[j].find_first_of(',')) == r1) {
					if (type[j] == "addi")addi = true;
				}
			}
			for (int j = 0; j < loop_times; j++) {				
				if (r2 == "R0"&&addi)loop_pattern += 'T';//r2=0+addi+bne �@�w�OT
				else loop_pattern += 'N';
			}
			pattern[i] = loop_pattern;
		}
	}
}

void Prediction() {
	for (int i = 0; i < entry_num; i++) {
		cout << "Entry: " << i << endl;
		char last = 'N';
		int miss = 0;
		int max=0;
		for (int k = 0; k < pattern.size(); k++) {
			if (pattern[k].size() > max)max = pattern[k].size();
		}//��X�̪���pattern
		for (int k = 0; k <max; k++) {//k==size
			for (int j = 0; j < inst.size(); j++) {
				if ((entry_pos[j] == i) && (pattern[j] != "")&&(k!=pattern[j].size())) {
					cout << "          " << type[j] << " " << inst[j] << endl;
					int state_num;
					if (state[i].bit[1] == 0 && state[i].bit[0] == 0)state_num = 0;
					else if (state[i].bit[1] == 0 && state[i].bit[0] == 1)state_num = 1;
					else if (state[i].bit[1] == 1 && state[i].bit[0] == 0)state_num = 2;
					else if (state[i].bit[1] == 1 && state[i].bit[0] == 1)state_num = 3;
					if (state[i].state_table[state_num][1] != pattern[j][k])miss++;//���P�_�O�]���n������X��
					cout << "          (" << state[i].bit[1] << state[i].bit[0] << ", " << state[i].state_table[0] << ", " << state[i].state_table[1] << ", " << state[i].state_table[2] << ", " << state[i].state_table[3] << ")";
					cout << "     prediction/outcome : " << state[i].state_table[state_num][1] << "/" << pattern[j][k] << "     misprediction: " << miss << endl;
					if (pattern[j][k] == 'N')last = 0;
					else last = 1;
					state[i].bit[1] = state[i].bit[0];
					state[i].bit[0] = last;
					if (state[i].state_table[state_num][1] != pattern[j][k]) {
						for (int m = 0; m < 4; m++) {
							if (state[i].state_table[state_num] == state_format[m]) {
								state[i].state_table[state_num] = Wrong[m];
								break;
							}
						}
					}
					else {
						for (int m = 0; m < 4; m++) {
							if (state[i].state_table[state_num] == state_format[m]) {
								state[i].state_table[state_num] = Right[m];
								break;
							}
						}
					}


				}
			}
		}
		

	}
}

int main() {
	ifstream fin("input.txt");
	string input;
	while (getline(fin, input)) {
		//cout << input << endl;
		stringstream in;
		string input_part, input_inst;
		in << input;//�h���h�l���ť�
		int x = 0;
		while (in >> input_part) {
			//cout << input_part << endl;
			if (x == 0) {
				if (input_part.find(':') != -1) {
					label.push_back(input_part.substr(0, input_part.find(':')));
					x = 0;
					PC.push_back("");
					type.push_back("");
					inst.push_back("");
					continue;
				}//��label
				else {
					label.push_back("");
					PC.push_back(input_part);
					x++;
				}//�S��label�N�Otype_name
			}
			else if (x == 1) {
				type.push_back(input_part);
				x++;
			}
			else if (x == 2&& input_part != ";"&&input_part!=" ") {
				input_inst += input_part;//�ѤU�����Oinst.���e
			}
		}
		if (x != 0)
			inst.push_back(input_inst);
	} //�B�zinput�榡
	cout << "Please input entry (entry>0) :" << endl;
	cin >> entry_num;
	while (entry_num <= 0) {
		cout<<"Entry must more than 0."<<endl;
		cout << "Please input entry (entry>0) :" << endl;
		cin>> entry_num;
	}
	for (int i = 0; i < entry_num; i++) {
		prediction p0;
		state.push_back(p0);
	}
	for (int i = 0; i < inst.size(); i++) {
		pattern.push_back("");
	}
	CALC_entry(entry_num);//�p��C��inst.��entry
	CALC_li();//�p��li��l��
	CALC_branch();//�p��branch�����A(nn...nt)
	Prediction();
	return 0;
}