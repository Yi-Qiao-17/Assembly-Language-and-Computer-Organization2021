#include<iostream>
#include<string>
#include<vector>
#include<sstream>
#include<fstream>
#include <cstdlib>
#include <iomanip>
#include<algorithm>
using namespace std;

typedef struct inst_member1 {
	string a = "";
	string b = "";
	string c = "";
};//3��register

vector<string>type, inst;
vector<inst_member1>temp;


inst_member1 string_function3(string in) {
	inst_member1 temp;
	temp.a = in.substr(0, in.find_first_of(','));
	temp.b = in.substr(in.find_first_of(',') + 1, in.find_last_of(',') - in.find_first_of(',') - 1);
	temp.c = in.substr(in.find_last_of(',') + 1, in.size() - in.find_last_of(',') - 1);
	return temp;
}//a,b,c

inst_member1 string_function1(string in) {
	inst_member1 temp;
	temp.a = in.substr(0, in.find(','));
	temp.b = in.substr(in.find(',') + 1, in.find('(') - in.find(',') - 1);
	temp.c = in.substr(in.find('(') + 1, in.find(')') - in.find('(') - 1);
	return temp;
}//a,b(c)

int RAW(inst_member1 right , int pos) {
	int tmp = -1;
	for (int i = 0; i < pos; i++) {
		if (right.b == temp[i].a || right.c == temp[i].a)tmp = i;
	}
	return tmp;
}

bool SameRS(inst_member1 right, int pos/*�ĴX�ӫ��O*/, int value/*�ثe���O��dispatch�ƭ�*/, int** mat) {
	string tmp = type[pos];//�ثe���O��type EX.ADD

	for (int i = 0; i < pos; i++) { //�p�G�PRS�S���@�˪�diapatch
		if (tmp == "ADD" || tmp == "SUB") {
			if (mat[i][1] == value && (type[i] == "ADD" || type[i] == "SUB"))return true;
		}
		else if (tmp == "LD") {
			if (mat[i][1] == value && type[i] == "LD" )return true;
		}
		else if (tmp == "MUL" || tmp == "DIV") {
			if (mat[i][1] == value && (type[i] == "MUL" || type[i] == "DIV"))return true;
		}
	}
	return false;
}

int SameRS_dispatch(inst_member1 right, int pos/*�ĴX�ӫ��O*/, int value/*�ثe���O��dispatch�ƭ�*/, int** mat) {
	string tmp = type[pos];//�ثe���O��type EX.ADD
	int return_value = -1;//�S�������p
	for (int i = 0; i < pos; i++) { //�p�G�PRS�S���@�˪�diapatch
		if (tmp == "ADD" || tmp == "SUB") {
			if (mat[i][2] > value && (type[i] == "ADD" || type[i] == "SUB"))return_value=i;
		}
		else if (tmp == "LD") {
			if (mat[i][2] > value && type[i] == "LD")return_value = i;
		}
		else if (tmp == "MUL" || tmp == "DIV") {
			if (mat[i][2] > value && (type[i] == "MUL" || type[i] == "DIV"))return_value = i;
		}
	}
	return return_value;
}

int main() {
	ifstream fin("input.txt");
	///�Ĥ@�B�G�B�z�榡/////////////////////////////////////////////////
	string input;
	while (getline(fin, input)) {
		//cout << input << endl;
		stringstream in;
		string input_part, input_inst;
		in << input;//�h���h�l���ť�
		int x = 0;
		while (in >> input_part) {
			//cout << input_part<<endl;
			 if (x == 0) {
				type.push_back(input_part);
				x++;
			}
			else if (x == 1) {
				input_inst += input_part;//�ѤU�����Oinst.���e
			}
		}
		inst.push_back(input_inst);
	}//�B�zinput�榡

	for (int i = 0; i < type.size(); i++) {
		if (inst[i].find('(') != -1) {
			inst_member1 tmp = string_function1(inst[i]);
			temp.push_back(tmp);
		}// a,b(c)
		else {
			inst_member1 tmp = string_function3(inst[i]);
			temp.push_back(tmp);
		}//a,b,c
	}
	//��Xinput
	cout << "Input instruction : " << endl;
	cout << "-------------------" << endl;
	for (int i = 0; i < inst.size(); i++) {
		cout <<"|"<<left<< setw(5) << type[i] <<left<< setw(12) << inst[i]<<"|" << endl;
	}
	cout << "-------------------" << endl;
	cout << endl;
	///�ĤG�B�G�ت�/////////////////////////////////////////////////////////////
	int** mat;
	mat = new int* [inst.size()];
	for (int i = 0; i < inst.size(); i++) {
		mat[i] = new int[3];//3��col
	}

	//issue �����q1�}�l
	for (int i = 0; i < inst.size(); i++) {
		mat[i][0] = i + 1;
	}

	//dispatch �`�N1.RAW�n�� 2.�PRS�n�� + cycle=wirte back
	for (int i = 0; i < inst.size(); i++) {
		int mark = RAW(temp[i], i);//�^�Ǧ�RAW���Y�����O��m
		int mat_tmp=mat[i][0]+1;//�Хܥثe�P�_��dispatch��
		
		////////////RAW
		if (mark != -1) {
			mat_tmp = mat[mark][2] + 1;//����RAW���Y�����OWrite Back��~diapatch
		}//��RAW
		else {
			mat_tmp = mat[i][0] + 1;//�S��RAW������issue+1�N�i�Hdispatch
		}

		///////RS type //�p�G�PRS�S���@�˪�diapatch //bool
		if (SameRS(temp[i], i, mat_tmp, mat))mat_tmp = mat_tmp + 1;

		///////RS type //�p�G�PRS �M��e���٦bdispatch //int
		mark = SameRS_dispatch(temp[i], i, mat_tmp, mat);
		if (mark!=-1)mat_tmp = mat[mark][2];

		////////////////////////////dispatch
		mat[i][1] = mat_tmp;

		//////////// #cycle
		if (type[i] == "ADD" || type[i] == "SUB"|| type[i] == "LD") {
			mat[i][2] = mat[i][1] + 2;
		}
		else if (type[i] == "MUL") {
			mat[i][2] = mat[i][1] + 10;
		}
		else if (type[i] == "DIV") {
			mat[i][2] = mat[i][1] + 40;
		}
		
	}

	//��X����
	cout << "Tomasulo's algorithm table :" << endl;
	cout << "-------------------------------------------------" << endl;
	cout <<"|"<< setw(17) << "Instruction" <<"|"<<setw(6)<<"Issue"<< "|"<<setw(9) << "Dispatch" <<"|"<< setw(12) << "Write result" <<"|"<< endl;
	for (int i = 0; i < inst.size(); i++) {
		cout << "|" <<left<< setw(5) << type[i] <<left<< setw(12) << inst[i] << "|" << setw(6) << mat[i][0] << "|" << setw(9) << mat[i][1] << "|" << setw(12) << mat[i][2] << "|" << endl;
	}
	cout << "-------------------------------------------------" << endl;
	cout << endl;
	///�ĤT�B�G�B�zRF�BRAT�BRS�BLOAD//////////////////////////////////////////////////////////////////////////////////////////
	
	//�B�zRF�MRAT�����Ǥ��e
	vector<string>register_name;
	//�@�}�l�֩w�S��register	,������J
	if (temp[0].a.find('R') != -1 || temp[0].a.find('F') != -1) {//���O�Ʀr�Oregister�n����
		register_name.push_back(temp[0].a);
	}
	//���L�n�O����
	for (int i = 0; i < temp.size(); i++) {
		bool inside[3] = {false,false,false};//�ΨӧP�_�n���n��Jregister_name//false�N�O���b�̭��A�n��J
		for (int j = 0; j < register_name.size(); j++) {
			if (temp[i].a.find('R') != -1 || temp[i].a.find('F') != -1) {//���O�Ʀr�Oregister
				if (temp[i].a == register_name[j]) {					
					inside[0] = true;					
				}
			}
			else if (temp[i].a.find('R') == -1 && temp[i].a.find('F') == -1) {//���O�Ʀr�Oregister
				inside[0] = true;
			}

			if (temp[i].b.find('R') != -1 || temp[i].b.find('F') != -1) {//���O�Ʀr�Oregister
				if (temp[i].b == register_name[j]) {
					inside[1] = true;
				}
			}
			else if (temp[i].b.find('R') == -1 && temp[i].b.find('F') == -1) {//�Ʀr
				inside[1] = true;
			}

			if (temp[i].c.find('R') != -1 || temp[i].c.find('F') != -1) {//�Ʀr
				if (temp[i].c == register_name[j]) {
					inside[2] = true;
				}
			}
			else if (temp[i].c.find('R') == -1 && temp[i].c.find('F') == -1) {//���O�Ʀr�Oregister
				inside[2] = true;
			}
			
		}
		for (int j = 0; j < 3; j++) {
			if (!inside[j]) {
				if(j==0)register_name.push_back(temp[i].a);
				else if(j==1)register_name.push_back(temp[i].b);
				else if (j == 2)register_name.push_back(temp[i].c);
			}
		}
	}
	sort(register_name.begin(), register_name.end());

	vector<int>register_value;
	//�w�qregister_name�̭�����
	for (int i = 0; i < register_name.size(); i++){
		register_value.push_back(2*i);
	}
	
	//�B�z��X
	int max = 0;//��X�̫᪺cycle
	for (int i = 0; i < inst.size(); i++) {
		if (max < mat[i][2])max = mat[i][2];
	}

	//�إ�cycle���A���ʧ@��cycle��true
	bool* cycle = new bool[max];
	for (int i = 0; i < max; i++)cycle[i] = false;
	for (int i = 0; i < inst.size(); i++) {
		for (int j = 0; j < 3; j++) {
			cycle[mat[i][j] - 1] = true;
		}
	}
	
	//��X//////////////////////////////////////////////////////////////////////////////////////////
	//RS/////////////////////////////////////////////////////////////////////
	vector<bool>RS_use = {false,false, false, false, false};//���S���Ψ�
	vector<string>RS_symbol (5);//�Ĥ@��
	vector<string>RS_1(5);//����RS����b
	vector<string>RS_2(5);//����RS����c
	vector<int>RS_pos = {-1,-1,-1,-1,-1};//����RS����inst[i]��i
	vector<string>RS_buffer(2);
	//LOAD/////////////////////////////////////////////////////////
	vector<bool>LOAD_use = { false,false, false };//���S���Ψ�
	vector<string>LOAD_1(3);//����LOAD����
	vector<string>LOAD_2(3);//����LOAD����
	vector<int>LOAD_pos = {-1,-1,-1};//����LOAD����inst[i]��i
	string LOAD_buffer = "";
	//RAT////////////////////////////////////////////////////////////////
	vector<bool>RAT_use(register_name.size());//����RAT���L�ϥ�
	vector<string>RAT(register_name.size());//�����̭��n�񤰻�
	for (int i = 0; i < register_name.size(); i++) {
		RAT_use[i] = false;
	}
	//////////////////////////////////////////////////////////////////////////////////////////
	for (int j = 0; j < max; j++) {
		if (!cycle[j])continue;//�p�G����cycle�S���Ʊ��n�B�z�N����X
	
		int issue = -1;//�O�����@�ӭnissue
		int dispatch[3] = {-1,-1,-1};//�����RS�M�@��LOAD�ҥH�@���̦h�i�H�T��inst�bdispatch
		int write_back = -1;
		
		for (int i = 0; i < inst.size(); i++) {//��nissue���O����inst
			if (mat[i][0] == j+1)issue = i;
			if (mat[i][1] == j+1) {
				for (int k = 0; k < 3; k++) {
					if (dispatch[k] == -1) {
						dispatch[k] = i;
						break;
					}
				}
			}
			if (mat[i][2] == j+1)write_back = i;
		}
		//issue
		if (issue != -1) {//���nissue�B���D�Oinst[i]
			int pos = -1;
			//���P�_type�A��RS�άOLOAD���S���Ŧ�
			if (type[issue] == "ADD" || type[issue] == "SUB") {
				for (int i = 0; i < 3; i++) {
					if (!RS_use[i]) {
						RS_pos[i] = issue;//�p�GRS�O�Ū��N�i�H��
						if (type[issue] == "ADD")RS_symbol[i] = '+';
						else RS_symbol[i] = '-';
						RS_use[i] = true;
						//�P�_RAT�����L�ϥΡA�S���ϥδN�O�ϥ�register������RF�A���ϥδN�O��Jregister������RAT
						for (int k = 0; k < register_name.size(); k++) {
							if (temp[issue].b == register_name[k]) {
								if (!RAT_use[k])RS_1[i] = to_string(register_value[k]);
								else RS_1[i] = RAT[k];
							}
							if (temp[issue].c == register_name[k]) {
								if (!RAT_use[k])RS_2[i] = to_string(register_value[k]);
								else RS_2[i] = RAT[k];
							}
						}
						//�n��RS��JRAT
						for (int k = 0; k < register_name.size(); k++) {
							if (register_name[k] == temp[issue].a) {
								RAT_use[k] = true;
								RAT[k] = "RS" + to_string(i + 1);
							}
						}
						break;
					}
				}
			}
			else if (type[issue] == "MUL" || type[issue] == "DIV") {
				for (int i = 3; i < 5; i++) {
					if (!RS_use[i]) {
						RS_pos[i] = issue;//�p�GRS�O�Ū��N�i�H��
						if (type[issue] == "MUL")RS_symbol[i] = '*';
						else RS_symbol[i] = '/';
						RS_use[i] = true;
						//�P�_RAT�����L�ϥΡA�S���ϥδN�O�ϥ�register������RF�A���ϥδN�O��Jregister������RAT
						for (int k = 0; k < register_name.size(); k++) {
							if (temp[issue].b == register_name[k]) {
								if (!RAT_use[k])RS_1[i] = to_string(register_value[k]);
								else RS_1[i] = RAT[k];
							}
							if (temp[issue].c == register_name[k]) {
								if (!RAT_use[k])RS_2[i] = to_string(register_value[k]);
								else RS_2[i] = RAT[k];
							}
						}
						//�n��RS��JRAT
						for (int k = 0; k < register_name.size(); k++) {
							if (register_name[k] == temp[issue].a) {
								RAT_use[k] = true;
								RAT[k] = "RS" + to_string(i + 1);
							}
						}
						break;
					}
				}
			}
			else if (type[issue] == "LD") {
				for (int i = 0; i < 3; i++) {
					if (!LOAD_use[i]) {
						LOAD_pos[i] = issue;//�p�G�O�Ū��N�i�H��
						LOAD_use[i] = true;
						LOAD_1[i] = temp[issue].b;
						LOAD_2[i] = temp[issue].c;
						//�n��LOAD��JRAT
						for (int k = 0; k < register_name.size(); k++) {
							if (register_name[k] == temp[issue].a) {
								RAT_use[k] = true;
								RAT[k] = "LOAD" + to_string(i + 1);
							}
						}
						break;
					}
				}
			}
			
		}//issue�B�z///////////////////////////////////////////////
		//dispatch
		for (int i = 0; i < 3; i++) {
			if (dispatch[i] == -1)continue;
			for (int k = 0; k < 5; k++) {
				if (RS_pos[k] == dispatch[i]&&RS_use[k]) {
					if (k < 3)RS_buffer[0]= "(RS" + to_string(k) + ") " + RS_1[k] +" "+ RS_symbol[k]+" "+ RS_2[k];
					else RS_buffer[1] = "(RS" + to_string(k) + ") " + RS_1[k] + " " + RS_symbol[k] + " " + RS_2[k];
				}
			}
			for (int k = 0; k < 3; k++) {
				if (LOAD_pos[k] == dispatch[i]&LOAD_use[k]) {
					LOAD_buffer = "(LOAD" + to_string(k) + ") " + LOAD_1[k] + " + " + LOAD_2[k];
				}
			}
		}//////////////////////////////////
		//write back
		if (write_back != -1) {
			//RS
			for (int k = 0; k < 5; k++) {
				if (RS_pos[k] == write_back&&RS_use[k]) {
					//��inst����b�Mc���ȩMa����m
					int b_value, c_value, a_pos;
					if (temp[RS_pos[k]].b.find('R') == -1 && temp[RS_pos[k]].b.find('F') == -1)b_value = atoi(temp[RS_pos[k]].b.c_str());//�O�Ʀr
					else {//�Oregister(RF)
						for (int i = 0; i < register_name.size(); i++) {
							if (register_name[i] == temp[RS_pos[k]].b) b_value = register_value[i];
							if (register_name[i] == temp[RS_pos[k]].c) c_value = register_value[i];
							if (register_name[i] == temp[RS_pos[k]].a) a_pos = i;
						}
					}

					int sum;//�p�⤧�᪺���G
					if (k < 3) {
						if (RS_symbol[k] == "+") {
							sum = b_value + c_value;
						}
						else {
							sum = b_value - c_value;
						}
						RS_buffer[0] = "";
					}
					else {
						if (RS_symbol[k] == "*") {
							sum = b_value * c_value;
						}
						else {
							sum = b_value / c_value;
						}
						RS_buffer[1] = "";
					}

					//�B�zRS�����Ψ�RAT������
					string str = "RS" + to_string(k + 1);
					for (int i = 0; i < RAT.size(); i++)
					{
						if (RAT_use[i] && RAT[i] == str) {//��RAT���nwb��������RS����
							RAT_use[i] = false;
							RAT[i] = "";
						}
					}
					for (int i = 0; i < 5; i++)//�ˬdRS�����S���n�ק�RSi������
					{
						if (RS_1[i] == str) {
							RS_1[i] = to_string(sum);
						}
						if (RS_2[i] == str) {
							RS_2[i] = to_string(sum);
						}
					}
					//��ȩ�J�۹�����RF
					register_value[a_pos] = sum;
					//��RS[k]�M���b
					RS_use[k] = false;
					RS_1[k] = "";
					RS_2[k] = "";
					RS_pos[k] = -1;
					RS_symbol[k] = "";
				}
			}

			//LOAD
			for (int k = 0; k < 3; k++) {
				if (LOAD_pos[k] == write_back&&LOAD_use[k]) {
					//��inst����b�Mc���ȩMa����m,b�O�Ʀr,a&c�Oregister
					int b_value, c_value, a_pos;
					b_value = atoi(temp[LOAD_pos[k]].b.c_str());//�O�Ʀr
					for (int i = 0; i < register_name.size(); i++) {//�Oregister(RF)
						if (register_name[i] == temp[LOAD_pos[k]].c) c_value = register_value[i];
						if (register_name[i] == temp[LOAD_pos[k]].a) a_pos = i;
					}
					
					int sum;//�p�⤧�᪺���G
					sum = b_value + c_value;
					LOAD_buffer = "";
					//�B�zRS�����Ψ�RAT������
					string str = "LOAD" + to_string(k + 1);
					for (int i = 0; i < RAT.size(); i++)
					{
						if (RAT_use[i] && RAT[i] == str) {//��RAT���nwb��������RS����
							RAT_use[i] = false;
							RAT[i] = "";
						}
					}
					for (int i = 0; i < 5; i++)//�ˬdRS�����S���n�ק�LOADi������
					{
						if (RS_1[i] == str) {
							RS_1[i] = to_string(sum);
						}
						if (RS_2[i] == str) {
							RS_2[i] = to_string(sum);
						}
					}
					//��ȩ�J�۹�����RF
					register_value[a_pos] = sum;
					//��LOAD[k]�M���b
					LOAD_use[k] = false;
					LOAD_1[k] = "";
					LOAD_2[k] = "";
					LOAD_pos[k] = -1;
				}
			}
		}

		//��X
		cout << "Cycle : " << j+1 << endl;
		//RF
		cout << setw(4) << "" << left << setw(5) << "--" << "RF" << setiosflags(ios::right) << setw(5) << "--" << endl;
		for (int i = 0; i < register_name.size(); i++) {
			cout << left << setw(4) << register_name[i] << "|" << right << setw(10) << register_value[i] << "|" << endl;
		}
		cout << setw(4) << "" << "------------" << endl;

		//RAT
		cout << setw(4) << "" << left << setw(5) << "--" << "RAT" << setiosflags(ios::right) << setw(4) << "--" << endl;
		for (int i = 0; i < register_name.size(); i++) {
			cout << left << setw(4) << register_name[i] << "|" << right << setw(10) << RAT[i] << "|" << endl;
		}
		cout << setw(4) << "" << "------------" << endl;

		//RS
		cout << setw(4) << "" <<left << setw(8) << "-----" << "RS(ADD)" << setiosflags(ios::right) << setw(8) << "-----" << endl;
		for (int i = 0; i < 3; i++) {
			cout << "RS" << left << setw(2) << i + 1 << "|" << right<<setw(7) << RS_symbol[i] <<"|"<< right << setw(7) << RS_1[i] << "|" << right << setw(7) << RS_2[i] << "|" << endl;
		}
		cout << setw(4) << "" << "-------------------------" << endl;
		cout << "BUFFER : "<<RS_buffer[0] << endl;
		cout << setw(4) << "" << left << setw(8) << "-----" << "RS(MUL)" << setiosflags(ios::right) << setw(8) << "-----" << endl;
		for (int i = 3; i < 5; i++) {
			cout << "RS" << left << setw(2) << i + 1 << "|" << right << setw(7) << RS_symbol[i] << "|" << right << setw(7) << RS_1[i] << "|" << right << setw(7) << RS_2[i] << "|" << endl;
		}
		cout << setw(4) << "" << "-------------------------" << endl;
		cout << "BUFFER : " <<RS_buffer[1]<< endl;


		//LOAD
		cout << setw(6) << "" << left << setw(4) << "--" << "LOAD" << setiosflags(ios::right) << setw(4) << "--" << endl;
		for (int i = 0; i < 3; i++) {
			string ss;
			if (LOAD_use[i])ss = LOAD_1[i] + "+" + LOAD_2[i];
			else ss = "";
			cout << "LOAD" << left << setw(2) << i + 1 << "|" <<right<< setw(10) << ss << "|" << endl;
		}
		cout << setw(6) << "" << "------------" << endl;
		cout << "BUFFER : " << LOAD_buffer << endl << endl<<endl<<endl;
	}

	

	
	//�̫�G�R���G���ʺA�}�C////////////////////////////////////////////////////////////////////////
	for (int i = 0; i < inst.size(); i++) {
		delete[]mat[i];
	}
	delete[] mat;
}