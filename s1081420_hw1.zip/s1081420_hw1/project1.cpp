#include<iostream>
#include<string>
#include<vector>
#include<sstream>
#include<fstream>
#include <cstdlib>
using namespace std;

vector<string>label, type, inst;

static string I_Type[12] = { "jalr", "lb", "lh",  "lw",  "lbu",  "lhu",  "addi",  "slti",  "sltiu",  "xori", "ori", "andi" };
static string I_Fun3[12] = { "000", "000", "001",  "010",  "100",  "101",  "000",  "010",  "011",  "100", "110", "111" };
static string R_Type[13] = { "slli", "srli", "srai",  "add",  "sub",  "sll",  "slt",  "sltu", "xor", "srl","sra","or", "and" };
static string R_Fun3[13] = { "001", "101", "101",  "000",  "000",  "001",  "010",  "011", "100", "101","101","110", "111" };
static string S_Type[3] = { "sb", "sh", "sw" };
static string S_Fun3[3] = { "000", "001", "010" };
static string U_Type[2] = { "lui","auipc" };
static string UJ_Type[1] = { "jal" };
static string SB_Type[6] = { "beq","bne","blt","bge","bltu","bgeu" };
static string SB_Fun3[6] = { "000","001","100","101","110","111" };

typedef struct inst_member1 {
	string a = "";
	string b = "";
	string c = "";
};//3��register

typedef struct inst_member2 {
	string a = "";
	string b = "";
};//2��register

int register_converto_int(string s,int label_begin) {
	int temp = 0;
	bool is_label = false;
	int label_end = 0;
	for (int i = 0; i < label.size(); i++) {
		if (s == label[i]) {
			is_label = true;
			label_end = i;
			break;
		}
	}
	if (s[0] == 'x') {
		if (is_label) {
			temp = (label_end - label_begin) * 4;
		}
		else {
			s = s.erase(0, 1);
			temp = atoi(s.c_str());
		}
	}
	else {
		if (is_label) {
			temp = (label_end - label_begin) * 4;
		}
		else {
			temp = atoi(s.c_str());
		}
	}
	return temp;
}

inst_member1 string_function1(string in) {
	inst_member1 temp;
	temp.a = in.substr(0, in.find(','));
	temp.b = in.substr(in.find(',') + 1, in.find('(') - in.find(',') - 1);
	temp.c = in.substr(in.find('(') + 1, in.find(')') - in.find('(') - 1);
	return temp;
}//a,b(c)

inst_member2 string_function2(string in) {
	inst_member2 temp;
	temp.a = in.substr(0, in.find_first_of(','));
	temp.b = in.substr(in.find_last_of(',') + 1, in.size() - in.find_last_of(',') - 1);
	return temp;
}//a,b

inst_member1 string_function3(string in) {
	inst_member1 temp;
	temp.a = in.substr(0, in.find_first_of(','));
	temp.b = in.substr(in.find_first_of(',') + 1, in.find_last_of(',') - in.find_first_of(',') - 1);
	temp.c = in.substr(in.find_last_of(',') + 1, in.size() - in.find_last_of(',') - 1);
	return temp;
}//a,b,c

string toBinary(string in,int size,int label_pos)
{
	bool negative = false;
	int n = register_converto_int(in, label_pos);
	if (n < 0) {
		negative = true;
		n *=(-1);
	}
	string r = "";
	while (r.size() < size) {
		r = (n % 2 == 0 ? "0" : "1") + r;
		n /= 2;
	}//��G�i��
	if (negative) {
		for (int i = 0; i < r.size(); i++) {
			if (r[i] == '0')r[i] = '1';
			else r[i] = '0';
		}
		if (r[0] == '0')r[r.size() - 1] = '1';
		else {
			//r[r.size() - 1] = '0';
			int carry = 1;
			for (int i = r.size() - 1; i >= 0; i--) {
				if (carry == 0)break;
				if ((r[i] - '0') + carry == 1) {
					r[i] = '1';
					carry = 0;
				}
				else if ((r[i] - '0') + carry == 2) {
					r[i] = '0';
					carry = 1;
				}
			}
		}
	}//�p�G�O�t��
	return r;
}//2�i��

void I_Type_Func(string type, inst_member1 inst, int type_pos,int inst_pos/*for label*/) {
	if (type_pos == 0) {
		cout << toBinary(inst.c, 12, inst_pos) <<" "<< toBinary(inst.b, 5, inst_pos) << " " << I_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "1100111" << endl;
	}
	else if (type_pos >=1 && type_pos <=5) {
		cout << toBinary(inst.b, 12, inst_pos) << " " << toBinary(inst.c, 5, inst_pos) << " " << I_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0000011" << endl;
	}
	else {
		cout << toBinary(inst.c, 12, inst_pos) << " " << toBinary(inst.b, 5, inst_pos) << " " << I_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0010011" << endl;
	}
}

void S_Type_Func(string type, inst_member1 inst, int type_pos, int inst_pos) {
	cout << toBinary(inst.b, 12, inst_pos).substr(0, 7) << " " << toBinary(inst.a, 5, inst_pos) << " " << toBinary(inst.c, 5, inst_pos) << " " << S_Fun3[type_pos] << " " << toBinary(inst.b, 12, inst_pos).substr(7, 5) << " " << "0100011" << endl;
}

void R_Type_Func(string type, inst_member1 inst, int type_pos, int inst_pos) {
	if (type_pos >= 0 && type_pos <= 2) {
		if (type_pos == 2) {
			cout << "01000" << " " << "00" << " " << toBinary(inst.c, 5, inst_pos) << " " << toBinary(inst.b, 5, inst_pos) << " " << R_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0010011" << endl;
		}//fun5 01000
		else {
			cout << "00000" << " " << "00" << " " << toBinary(inst.c, 5, inst_pos) << " " << toBinary(inst.b, 5, inst_pos) << " " << R_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0010011" << endl;
		}//fun5 00000
	}//opcode 0010011
	else {
		if (type_pos == 4 || type_pos == 10) {
			cout << "01000" << " " << "00" << " " << toBinary(inst.c, 5, inst_pos) << " " << toBinary(inst.b, 5, inst_pos) << " " << R_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0110011" << endl;
		}//fun5 01000
		else {
			cout << "00000" << " " << "00" << " " << toBinary(inst.c, 5, inst_pos) << " " << toBinary(inst.b, 5, inst_pos) << " " << R_Fun3[type_pos] << " " << toBinary(inst.a, 5, inst_pos) << " " << "0110011" << endl;
		}//fun5 00000
	}//opcode 0110011
}

void U_Type_Func(string type, inst_member2 inst, int type_pos, int inst_pos) {
	if (type_pos == 0)
		cout << toBinary(inst.b, 20, inst_pos) << " " << toBinary(inst.a, 5, inst_pos) << " " << "0110111" << endl;
	else cout << toBinary(inst.b, 20, inst_pos) << " " << toBinary(inst.a, 5, inst_pos) << " " << "0010111" << endl;
}

void UJ_Type_Func(string type, inst_member2 inst, int type_pos, int inst_pos) {
	string temp = toBinary(inst.b, 20, inst_pos);
	cout << temp.substr(0, 1) << " " << temp.substr(10, 10) << " " << temp.substr(9, 1) << " " << temp.substr(1, 8) << " " << toBinary(inst.a, 5, inst_pos) << " " << "1101111" << endl;
}

void SB_Type_Func(string type, inst_member1 inst, int type_pos, int inst_pos) {
	string temp = toBinary(inst.c, 12, inst_pos);
	cout << temp.substr(0, 1) << " " << temp.substr(2, 6) << " " << toBinary(inst.b, 5, inst_pos) << " " << toBinary(inst.a, 5, inst_pos) << " " << SB_Fun3[type_pos] << " " << temp.substr(8, 4) << " " << temp.substr(1, 1) << " " << "1100011" << endl;
}

int main() {
	/////////////test//////////////
	/*string s1 = "x11,x12(x13)";
	string s2 = "x14,x15";
	string s3 = "x5,x6,x7";
	inst_member1 temp1,temp3;
	inst_member2 temp2;
	temp1 = string_function1(s1);
	temp2 = string_function2(s2);
	temp3 = string_function3(s3);*/

	/////////////test/////////////////

	ifstream fin("input.txt");

	string input;
	while (getline(fin,input)) {
		//cout << input << endl;
		stringstream in;
		string input_part, input_inst;
		in << input;//�h���h�l���ť�
		int x = 0;
		while (in>>input_part) {
			//cout << input_part<<endl;
			if (x == 0) {
				if (input_part.find(':') != -1) {
					label.push_back(input_part.substr(0, input_part.find(':')));
					x++;
				}//��label
				else {
					label.push_back("");
					type.push_back(input_part);
					x += 2;
				}//�S��label�N�Otype_name
			}
			else if (x == 1) {
				type.push_back(input_part);
				x++;
			}
			else if(x==2){
				input_inst += input_part;//�ѤU�����Oinst.���e
			}
		}
		inst.push_back(input_inst);
	}//�B�zinput�榡

	for (int i = 0; i < type.size(); i++) {
		if (label[i] != "")
			cout << label[i] << ": "<< type[i] << " " << inst[i] << endl;
		else cout << " " << type[i] << " " << inst[i] << endl;
		if (inst[i].find('(') != -1) {
			bool out = false;
			inst_member1 temp = string_function1(inst[i]);
			for (int j = 1; j < 6; j++) {
				if (type[i] == I_Type[j]) {
					I_Type_Func(I_Type[j], temp, j, i);
					out = true;
				}
			}//I_type
			if (out)continue;
			for (int j = 0; j < 3; j++) {
				if (type[i] == S_Type[j]) {
					S_Type_Func(S_Type[j], temp, j, i);
				}
			}//S_type
		}// a,b(c)
		else if (inst[i].find_first_of(',') == inst[i].find_last_of(',')) {
			bool out = false;
			inst_member2 temp = string_function2(inst[i]);
			if (type[i] == UJ_Type[0]) {
				UJ_Type_Func(UJ_Type[0], temp, 0, i);
				out = true;
			}//uj type
			if (out)continue;
			for (int j = 0; j < 2; j++) {
				if (type[i] == U_Type[j]) {
					U_Type_Func(U_Type[j], temp, j, i);
				}
			}//U_type
		}// a,b
		else {
			bool out = false;
			inst_member1 temp = string_function3(inst[i]);

			if (type[i] == I_Type[0]) {
				I_Type_Func(I_Type[0], temp, 0, i);
			}//jalr [0]

			for (int j = 6; j < 11; j++) {
				if (type[i] == I_Type[j]) {
					I_Type_Func(I_Type[j], temp, j, i);
					out = true;
				}
			}//I_type [6:11]
			if (out)continue;
			for (int j = 0; j < 13; j++) {
				if (type[i] == R_Type[j]) {
					R_Type_Func(R_Type[j], temp, j, i);
					out = true;
				}
			}//R_type
			if (out)continue;
			for (int j = 0; j < 6; j++) {
				if (type[i] == SB_Type[j]) {
					SB_Type_Func(SB_Type[j], temp, j, i);
				}
			}//SB_type
		}// a,b,c
	}
	if (label.size() > type.size())cout << label[label.size() - 1] <<": "<< endl;
	label.clear();
	type.clear();//#machine code
	inst.clear();
	return 0;
}